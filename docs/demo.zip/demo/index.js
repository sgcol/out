console.log(`请求演示
使用request组件，很容易实现网页的访问
用法 https://www.npmjs.com/package/request`);

const request=require('request');
request('http://27.102.115.163:7090/pf/tony/report', {qs:{orderid:'testorder', err:'pending', money:100, time:new Date().getTime()}}, function(err, headers, body) {
    if (err) return console.log(err);
    console.log(body);
})